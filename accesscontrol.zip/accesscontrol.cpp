/**
Journal: Multimedia Tools and Applications 
Manuscript title: A 3-FACTOR AUTHENTICATION ACCESS CONTROL SYSTEM USING RFID, FINGERPRINT, TOKEN AND CODE.
Authors: Ndianabasi.H.Valentine1; Emmanuel .I. Akaerue1*; Mfon G. Etido2; Christopher S. Davies-Ekpo3
Corresponding Author: *emmanuelakaerue@unical.edu.ng*
*/
//RFID DEFINITION:
volatile unsigned char serial_buff[20];
unsigned char cant, kp_data = 0;
#define F_CPU 2000000UL
#define rfidbaud	12
#define rfidPin		2
#define relay1		0
#define relay2		1
//-------------------------------------------------------------
#define setBit(a,b) ((a) |= (1<<(b)))
#define clrBit(a,b) ((a) &=~(1<<(b)))
#define cplBit(a,b) ((a) ^= (1<<(b)))
#define chkBit(a,b) ((a) & (1<<(b)))
//-----------------------------------------------------------------
#include <avr/io.h>
#include <util/delay.h>
#include <MyAVR/lcd4bit.h>
#include <MyAVR/serial.h>
#include <MyAVR/dec2ascii.h>
//#include <avr/wdt.h>
#include <avr/pgmspace.h>
//-----------------------------------------------------------------
const char c0[] PROGMEM = "510066B12AAC";
const char c1[] PROGMEM = "85004F3712EF";
const char c2[] PROGMEM = "85004F1BAC7D";
const char c3[] PROGMEM = "85004F13A37A";
const char c4[] PROGMEM = "510067B1D156";
const char c5[] PROGMEM = "510064A83CA1";
const char c6[] PROGMEM = "5100669F9A32";
const char c7[] PROGMEM = "5100657589C8";
const char c8[] PROGMEM = "510064F3EC2A";
const char c9[] PROGMEM = "5100651FA48F";
PGM_P const c_table[] PROGMEM = {c0,c1,c2,c3,c4,c5,c6,c7,c8,c9};
char lcd_buffer[20];
const char hexa[] PROGMEM = {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};
ISR(USART_RXC_vect)
{
	serial_buff[cant] = UDR;
	cant++;
	if (cant == 20)
	{
		cant = 0;
	}
}
int main(void)
{
	void ready(void)
	{
		lcd_rub();
		lcd_string(" System Ready...");
		_delay_ms(1000);		
	}
	uint8_t EM18read(void)
	{
		_delay_ms(200);
		for (uint8_t a=1; a<4; a++)
		{
			strcpy_P(lcd_buffer, (PGM_P)pgm_read_word(&(c_table[a])));
			if (serial_buff[0]==lcd_buffer[0] && serial_buff[1]==lcd_buffer[1] && serial_buff[2]==lcd_buffer[2] && serial_buff[3]==lcd_buffer[3] && serial_buff[4]==lcd_buffer[4] && serial_buff[5]==lcd_buffer[5] && serial_buff[6]==lcd_buffer[6] && serial_buff[7]==lcd_buffer[7] && serial_buff[8]==lcd_buffer[8] && serial_buff[9]==lcd_buffer[9] && serial_buff[10]==lcd_buffer[10] && serial_buff[11]==lcd_buffer[11])
			{
				serial_buff[0] = a;
				break;
			}
		}
		return serial_buff[0];
	}
	void show(void)
	{
		lcd_rub();
		for (uint8_t a=0; a<16; a++)
		{
			lcd_write(serial_buff[a]);
		}
		_delay_ms(5000);
	}
	
	
    //==================================================================
	setBit(DDRC, relay1);
	setBit(DDRC, relay2);
	clrBit(PORTC, relay1);
	clrBit(PORTC, relay2);
	serial_init_inter(rfidbaud);
	lcd_init();
	lcd_string("RFID Based Acess");
	lcd_line2();
	lcd_string("Control System. ");
	_delay_ms(3000);
	//goto  aa;
	lcd_rub();
	
	_delay_ms(3000);
//aa:
	ready();
	while(1)
    {
        while(PIND & (1<<rfidPin));
		cant = 0;		
		kp_data = EM18read();
		//_delay_ms(150);
		//show();		
		
		if (kp_data < 6)
		{
			lcd_rub();
			lcd_string("Welcome User ");
			dec2ascii(kp_data, 2);
			lcd_line2();
			lcd_string("Access Granted.");
			setBit(PORTC, relay1);
			clrBit(PORTC, relay2);
			_delay_ms(700);
			clrBit(PORTC, relay1);
			clrBit(PORTC, relay2);			
			_delay_ms(5000);
			clrBit(PORTC, relay1);
			setBit(PORTC, relay2);
			_delay_ms(700);
			clrBit(PORTC, relay1);
			clrBit(PORTC, relay2);
			ready();
		}
		else
		{
			lcd_rub();
			lcd_string("Invalid Card !!!");			
			lcd_line2();
			lcd_string("Access Denied...");
			clrBit(PORTC, relay1);
			clrBit(PORTC, relay2);
			_delay_ms(3000);			
			ready();

    /**************** FINGERPRINT PROTOCOL DEFINITION AND CODE/TOKEN *******************/
    const unsigned char FP_Header[8] =	{0xEF,0x01,0xFF,0xFF,0xFF,0xFF,0x01,0x00};
    const unsigned char FP_SetPwd[8] =	{0x07,0x12,0xff,0xff,0xff,0xff,0x04,0x16};
    const unsigned char FP_VfyPwd[8] =	{0x07,0x13,0xff,0xff,0xff,0xff,0x04,0x17};
    const unsigned char FP_Get_Img[4] = {0x03,0x01,0x00,0x05};  //get/record fingerprint image
    const unsigned char FP_Store[3] =	{0x06,0x06,0x01};         //get total number of template
    const unsigned char FP_Search[9] =	{0x08,0x04,0x01,0x00,0x00,0x00,0xff,0x01,0x0d};
    const unsigned char FP_Temp_Num[4] ={0x03,0x1D,0x00,0x21};
    const unsigned char FP_Delet_All[4] = {0x03,0x0d,0x00,0x11};
    const unsigned char FP_rd_flash[5] = {0x04,0x19,0x01,0x00,0x1f};
    unsigned char FP_Img2Buffer1[5] = {0x04,0x02,0x01,0x0,0x08};  //save image to BUFFER1
    unsigned char FP_Img2Buffer2[5] = {0x04,0x02,0x02,0x0,0x09};  //save image to BUFFER2
    unsigned char FP_Reg_Model[4] =	{0x03,0x05,0x0,0x09};
    unsigned char FP_wr_flash[3] =	{0x24,0x18,0x01};
    unsigned char FP_Delete1by1[8] = {0x07,0x0C,0x00,0x0,0x00,0x01,0x00,0x00};
    /**********  RECIEVE DATA FROM FPM10A MODULE **************/
    void FPM10A_reciv(unsigned char count)
    {
	    do
	    {
		    serial_buff[0] = serial_rx();
	    } while (serial_buff[0] != 0xef);
	    for (unsigned char i=1; i<count; i++)
	    {
		    serial_buff[i] = serial_rx();
	    }
    }    
    /**************  PASSWORD VERIFICATION COMMAND ***********/
    void FPM10A_vfypwd(void)
    {
	    for(unsigned i=0; i<8; i++) //send header
	    serial_tx(FP_Header[i]);
	    for(unsigned i=0; i<8; i++) //send command 0x1d
	    serial_tx(FP_VfyPwd[i]);
    }
    /**********************PASSWORD SET COMMAND ****************/
    void FPM10A_Setpwd(void)
    {
	    for(unsigned i=0; i<8; i++) //send header
	    serial_tx(FP_Header[i]);
	    for(unsigned i=0; i<8; i++) //send command 0x1d
	    serial_tx(FP_SetPwd[i]);
    }
    /*****************   GETS FINGER PRINT ON SCANNER   ************/
    void FPM10A_Get_Img(void)
    {
	    for(unsigned i=0; i<8; i++) //send header
	    serial_tx(FP_Header[i]);
	    for(unsigned i=0; i<4; i++) //send command 0x1d
	    serial_tx(FP_Get_Img[i]);
	    FPM10A_reciv(10);
    }
    /*******************    SAVES IMAGE TO BUFFER1   *****************/
    void FPM10A_Img2Buffer1(void)
    {
	    for(unsigned i=0; i<8; i++) //send header
	    serial_tx(FP_Header[i]);
	    for(unsigned i=0; i<5; i++)
	    serial_tx(FP_Img2Buffer1[i]);
	    FPM10A_reciv(10);
    }
    /*******************   SAVES IMAGE TO BUFFER2   ******************/
    void FPM10A_Img2Buffer2(void)
    {
	    for(unsigned i=0; i<8; i++) //send header
	    serial_tx(FP_Header[i]);
	    for(unsigned i=0; i<5; i++)
	    serial_tx(FP_Img2Buffer2[i]);
	    FPM10A_reciv(10);
    }
    /************  REG MODEL BUFFER1 AND BUFFER2  ******************/
    void FPM10A_Reg_Model(void)
    {
	    for(unsigned i=0; i<8; i++) //send header
	    serial_tx(FP_Header[i]);
	    for(unsigned i=0; i<4; i++)
	    serial_tx(FP_Reg_Model[i]);
	    FPM10A_reciv(10);
    }
    /*********************** GET TEMPLATE NUMBER *********************/
    void FPM10A_Get_Temp_Num(void)
    {
	    for(unsigned i=0; i<8; i++) //send header
	    serial_tx(FP_Header[i]);
	    for(unsigned i=0; i<4; i++)
	    serial_tx(FP_Temp_Num[i]);
	    FPM10A_reciv(12);



K
COMPREHENSIVE SIMULATION MODE

#include <xc.h>
#include <stdlib.h>
#include <string.h>

#include "eeprom/eeprom.h"
#include "keypad/keypadex.h"
#include "timers/tickstimer.h"
#include "uart/uart_interrupt.h"
#include "xlcd/display.h"
#include "xlcd/xlcd.h"
#include "xlcd/xlcdcgram.h"

#include "globals.h"

#define SIMULATION_MODE
#define delay1s()    __delay_ms(250);__delay_ms(250);__delay_ms(250);__delay_ms(250);
#define PHONE_NO_SIZE   14

#define PANIC_BTN       PORTAbits.RA1
#define SENSOR_1        PORTBbits.RB0
#define SENSOR_2        PORTBbits.RB1
#define SENSOR_3        PORTBbits.RB2
#define STROBE          PORTEbits.RE0
#define EXT_SIREN       PORTEbits.RE1
#define INT_SIREN       PORTEbits.RE2
#define BLINKER         PORTCbits.RC5
#define DOOR_1          PORTDbits.RD2
#define DOOR_2          PORTDbits.RD3

char keypadBuffer[XLCD_COLS];
char tempBuffer[XLCD_COLS];
uchar colIndex = 0;

uchar pageIndex = START_PAGE;
uchar lastPageIndex = START_PAGE;
uchar menuCursor = 0;

ulong pageElapsed, eventElapsed;
ulong errorElapsed, securityElapsed;

void interrupt interruptISR()
{
    TickTimerISR();
    UARTIntISR();
}

uchar GetKeyPress()
{
    uchar kp;
    kp = KeypadPress();
    
#ifdef SIMULATION_MODE
    switch (kp)
    {
        case  1: kp = 55; break; // 7
        case  2: kp = 56; break; // 8
        case  3: kp = 57; break; // 9
        case  4: kp = 65; break; // / (A)   Menu/Enter
        case  5: kp = 52; break; // 4
        case  6: kp = 53; break; // 5
        case  7: kp = 54; break; // 6
        case  8: kp = 66; break; // * (B)   Escape
        case  9: kp = 49; break; // 1
        case 10: kp = 50; break; // 2
        case 11: kp = 51; break; // 3
        case 12: kp = 67; break; // - (C)   Scroll Up
        case 13: kp = 68; break; // ON(D)
        case 14: kp = 48; break; // 0
        case 15: kp = 69; break; // = (E)
        case 16: kp = 70; break; // + (F)   Scroll Down
        default: kp = 0;
    }

#else
    switch (kp)
    {
        case  1: kp = 49; break; // 1
        case  2: kp = 50; break; // 2
        case  3: kp = 51; break; // 3
        case  4: kp = 65; break; // A       Menu/Enter
        case  5: kp = 52; break; // 4
        case  6: kp = 53; break; // 5
        case  7: kp = 54; break; // 6
        case  8: kp = 66; break; // B       Escape
        case  9: kp = 55; break; // 7
        case 10: kp = 56; break; // 8
        case 11: kp = 57; break; // 9
        case 12: kp = 67; break; // C       Scroll Up
        case 13: kp = 68; break; // D
        case 14: kp = 48; break; // 0
        case 15: kp = 69; break; // E
        case 16: kp = 70; break; // F       Scroll Down
        default: kp = 0;
    }
#endif

    return kp;
}

uchar IsMatch()
{
    uchar idx, ep;
    
    for (idx=0; idx<XLCD_COLS; idx++)
    {
        ep = ReadEEProm8(EEPROM_ADDR_CODE+idx);
        tempBuffer[idx] = ep;
        
        if (ep == 0) {
            break;
        }
    }
    
    if (strncmp(keypadBuffer, tempBuffer, idx) == 0) {
        return 1;
    }
    
    return 0;
}

uchar ReadPhoneNumber(uchar addr, char* buffer)
{
    uchar idx, ep;
    memset(buffer, 0, PHONE_NO_SIZE+1);
    
    for (idx=0; idx<PHONE_NO_SIZE; idx++)
    {
        ep = ReadEEProm8(addr+idx);
        *(buffer+idx) = ep;
        
        if (ep == 0) {
            break;
        }
    }
    return idx;
}

void WritePhoneNumber(uchar addr, char* buffer)
{
    uchar idx, ep;
    
    for (idx=0; idx<PHONE_NO_SIZE; idx++)
    {
        ep = *(buffer+idx);
        WriteEEProm8(addr+idx, ep);
        
        if (ep == 0) {
            break;
        }
    }
    WriteEEProm8(addr+idx, 0);
}

void main()
{
    uchar kp, idx, ep_sens, sens_trigger, panicLevel = 0;
    uchar errorCnt = 0;
    uchar rx;
    
    errorElapsed = eventElapsed = pageElapsed = securityElapsed = 0;
    
    ADCON0 = 0b10000000;
    ADCON1 = 0b11001110;
    
    TRISB = 0xFF;
    TRISCbits.TRISC5 = 0;
    TRISD = 0xF3;
    PORTD = 0x00;
    TRISE = 0x00;
    PORTE = 0x00;
    
    InitTickTimer();
    KeypadInit();
    DisplayInit();
    UARTIntInit();
    
#ifdef __PICC__
    OPTION_REGbits.nRBPU = 0;
#else
    INTCON2bits.RBPU = 0;
#endif
    
    XlcdInitCustomChars();
    XlcdWriteCustomChar(ADDR_BATT_DISCHARGED);
    XlcdWriteCustomChar(ADDR_BATT_LOW);
    XlcdWriteCustomChar(ADDR_BATT_MEDIUM);
    XlcdWriteCustomChar(ADDR_BATT_HIGH);
    XlcdWriteCustomChar(ADDR_BATT_CHARGED);
    XlcdWriteCustomChar(ADDR_PLAY);
    XlcdWriteCustomChar(ADDR_CORRECT);
    XlcdFinalizeCustomChars();
    
    while (TRUE) {               
        if (TicksElapsed(&eventElapsed, 500)) {
            BLINKER = ~BLINKER;
        }
        
        if (UARTIntGetChar(&rx)) {
            UARTIntPutChar(rx);
        }
        
        //sens_trigger = 0;
        ep_sens = ReadEEProm8(EEPROM_ADDR_ALLSENSORS);
        
        if (ReadEEProm8(EEPROM_ADDR_DOOR_1)) {
            DOOR_1 = 1;
        } else {
            DOOR_1 = 0;
        }
        
        if (ReadEEProm8(EEPROM_ADDR_DOOR_2)) {
            DOOR_2 = 1;
        } else {
            DOOR_2 = 0;
        }

        if (ep_sens) {
            if (!SENSOR_1) {    // Low Trigger
                sens_trigger |= SENSOR_PAGE + 1;
                panicLevel |= 1;
            }

            if (!SENSOR_2) {    // Low Trigger
                sens_trigger |= SENSOR_PAGE + 2;
                panicLevel |= 1;
            }

            if (SENSOR_3) {     // High Trigger
                sens_trigger |= SENSOR_PAGE + 4;
                panicLevel |= 1;
            }
        }
          
        if (!PANIC_BTN) {
            sens_trigger |= SENSOR_PAGE + 8;
            panicLevel |= 2;
        }

        if (errorCnt > 2) {
            pageIndex = LOCK_PAGE;
        }
        
        if (sens_trigger || panicLevel) {
            if (pageIndex > START_PAGE) {
                if (TicksElapsed(&securityElapsed, 32000)) {
                    panicLevel--;
                    
                    if (!panicLevel) {
                        sens_trigger = 0;
                    }
                }
                pageIndex = SENSOR_PAGE;
                DisplayClearRomOut(1, 2, "");
                INT_SIREN = BLINKER;
                STROBE = EXT_SIREN = 1;
            }
        } else {
            if (pageIndex == SENSOR_PAGE) {
                pageIndex = MONITOR_PAGE;
                INT_SIREN = STROBE = EXT_SIREN = 0;
            }
        }
        
        switch (pageIndex) {
            case START_PAGE:
                DisplayClearRomOut(1, 1, MSG_SYSTEM CONTROL);
                DisplayClearRomOut(1, 2, MSG_VERSION);
                
                if (TicksElapsed(&pageElapsed, 2000)) {
                    pageIndex = MONITOR_PAGE;
                }

                break;
                
            case MONITOR_PAGE:
                if (ep_sens) {
                    DisplayClearRomOut(1, 1, MSG_SYSTEM_ARMED);
                    DisplayClearRomOut(1, 2, MSG_TRACKING);
                } else {
                    DisplayClearRomOut(1, 1, MSG_SYSTEM_DISARMED);
                    DisplayClearRomOut(1, 2, MSG_NO_TRACKING);
                }
                break;
                
            case ENTER_PW_PAGE:
                DisplayClearRomOut(1, 1, MSG_ENTER_PW);
                break;
                
            case OLD_PW_PAGE:
                DisplayClearRomOut(1, 1, MSG_OLD_PASSWORD);
                break;
                
            case NEW_PW_PAGE:
                DisplayClearRomOut(1, 1, MSG_NEW_PASSWORD);
                break;
                
            case REPEAT_PW_PAGE:
                DisplayClearRomOut(1, 1, MSG_RE_PASSWORD);
                break;
                
            case MENU_PAGE_0:
                DisplayClearRomOut(2, 1, MSG_CHANGE_PW);
                
                if (ReadEEProm8(EEPROM_ADDR_ALLSENSORS)) {
                    DisplayClearRomOut(2, 2, MSG_DEACTIVATE_SN);                                        
                } else {
                    DisplayClearRomOut(2, 2, MSG_ACTIVATE_SN);                    
                }
                DisplayRomCharOut(1, menuCursor+1, CCHAR_PLAY);
                break;
                
                        
            case MENU_PAGE_1:                                
                if (ReadEEProm8(EEPROM_ADDR_ALLSENSORS)) {
                    DisplayClearRomOut(2, 1, MSG_DEACTIVATE_SN);                                        
                } else {
                    DisplayClearRomOut(2, 1, MSG_ACTIVATE_SN);                    
                }
                
                if (ReadEEProm8(EEPROM_ADDR_DOOR_1)) {
                    DisplayClearRomOut(2, 2, MSG_UNLOCK_DOOR);                         
                } else {
                    DisplayClearRomOut(2, 2, MSG_LOCK_DOOR);           
                }
                DisplayAppendRomOut(2, " 1");
                DisplayRomCharOut(1, menuCursor+1, CCHAR_PLAY);                
                break;
                
            case MENU_PAGE_2:                
                if (ReadEEProm8(EEPROM_ADDR_DOOR_1)) {
                    DisplayClearRomOut(2, 1, MSG_UNLOCK_DOOR);                         
                } else {
                    DisplayClearRomOut(2, 1, MSG_LOCK_DOOR);           
                }
                DisplayAppendRomOut(1, " 1");
                
                if (ReadEEProm8(EEPROM_ADDR_DOOR_2)) {
                    DisplayClearRomOut(2, 2, MSG_UNLOCK_DOOR);                                        
                } else {
                    DisplayClearRomOut(2, 2, MSG_LOCK_DOOR);                    
                }
                DisplayAppendRomOut(2, " 2");
                DisplayRomCharOut(1, menuCursor+1, CCHAR_PLAY);                
                break;
                
            case MENU_PAGE_3:                
                if (ReadEEProm8(EEPROM_ADDR_DOOR_2)) {
                    DisplayClearRomOut(2, 1, MSG_UNLOCK_DOOR);                         
                } else {
                    DisplayClearRomOut(2, 1, MSG_LOCK_DOOR);           
                }
                DisplayAppendRomOut(1, " 2");
                
                DisplayClearRomOut(2, 2, MSG_SMS_CONTACTS);
                DisplayRomCharOut(1, menuCursor+1, CCHAR_PLAY);                
                break;
                
            case PER_CONTACT_PAGE:
                DisplayClearRomOut(1, 1, MSG_PER_CONTACT);
                DisplayClearRamOut(1, 2, keypadBuffer);
                break;
                
            case SEC_CONTACT_PAGE:
                DisplayClearRomOut(1, 1, MSG_SEC_CONTACT);
                DisplayClearRamOut(1, 2, keypadBuffer);
                break;
                
            case PAL_CONTACT_PAGE:
                DisplayClearRomOut(1, 1, MSG_PAL_CONTACT);
                DisplayClearRamOut(1, 2, keypadBuffer);
                break;
                
            case CHANGE_SUCCESS_PAGE:
                DisplayClearRomOut(1, 1, MSG_PW_CHANGE);
                DisplayClearRomOut(1, 2, MSG_SUCCESS);

                if (TicksElapsed(&pageElapsed, 2000)) {
                    pageIndex = MENU_PAGE_0;
                    menuCursor = 0;                    
                }
                break;

            case CHANGE_FAILURE_PAGE:
                DisplayClearRomOut(1, 1, MSG_PW_CHANGE);
                DisplayClearRomOut(1, 2, MSG_FAIL_MM);

                if (TicksElapsed(&pageElapsed, 2000)) {
                    pageIndex = lastPageIndex;
                    memset(keypadBuffer, 0, XLCD_COLS);
                    colIndex = 0;
                    DisplayClearRow(2);
                }
                break;
                
            case INVALID_PW_PAGE:
                DisplayClearRomOut(1, 1, MSG_INVALID_PW);
                DisplayClearRow(2);
                
                if (TicksElapsed(&pageElapsed, 2000)) {
                    pageIndex = lastPageIndex;
                    memset(keypadBuffer, 0, XLCD_COLS);
                    colIndex = 0;                    
                }
                break;   
                
            case LOCK_PAGE:
                DisplayClearRomOut(1, 1, MSG_INVALID_PW);
                DisplayClearRomOut(1, 2, MSG_SYSTEM_LOCKED);
                INT_SIREN = BLINKER;
                
                if (TicksElapsed(&errorElapsed, 32000)) {
                    DisplayClearRow(2);
                    errorCnt = 0;
                    pageIndex = lastPageIndex;
                    memset(keypadBuffer, 0, XLCD_COLS);
                    colIndex = 0;
                }
                break;
                
            case SENSOR_PAGE:
                if ((sens_trigger & (SENSOR_PAGE+1)) == (SENSOR_PAGE+1)) {
                    DisplayAppendRomOut(2, "ZN1 ");
                }

                if ((sens_trigger & (SENSOR_PAGE+2)) == (SENSOR_PAGE+2)) {
                    DisplayAppendRomOut(2, "ZN2 ");
                }

                if ((sens_trigger & (SENSOR_PAGE+4)) == (SENSOR_PAGE+4)) {
                    DisplayAppendRomOut(2, "ZN3 ");
                }

                if ((sens_trigger & (SENSOR_PAGE+8)) == (SENSOR_PAGE+8)) {
                    DisplayClearRomOut(1, 2, "PANIC MODE");
                }
                DisplayClearRomOut(1, 1, MSG_BREACH);
                break;
        }
        
        kp = GetKeyPress();
        
        switch (kp) {
            case 0:
                break;
                                
            case 'A':                                       // Menu
                switch (pageIndex) {
                    case MONITOR_PAGE:
                        pageIndex = ENTER_PW_PAGE;
                        DisplayClearRomOut(1, 1, MSG_ENTER_PW);
                        DisplayClearRow(2);
                        memset(keypadBuffer, 0, XLCD_COLS);
                        colIndex = 0;
                        break;
                        
                    case ENTER_PW_PAGE:
                        if (IsMatch()) {
                            pageIndex = MENU_PAGE_0;
                            menuCursor = 0;
                        } else {
                            lastPageIndex = pageIndex;
                            pageIndex = INVALID_PW_PAGE;
                            errorCnt++;
                        }                        
                        break;
                        
                    case MENU_PAGE_0:
                        if (menuCursor) {
                            if (ReadEEProm8(EEPROM_ADDR_ALLSENSORS)) {
                                WriteEEProm8(EEPROM_ADDR_ALLSENSORS, 0);
                            } else {
                                WriteEEProm8(EEPROM_ADDR_ALLSENSORS, 1);
                            }
                        } else {
                            pageIndex = OLD_PW_PAGE;
                            memset(keypadBuffer, 0, XLCD_COLS);
                            colIndex = 0;
                            
                            DisplayClearRomOut(1, 1, MSG_OLD_PASSWORD);
                            DisplayClearRow(2);
                        }                        
                        break;
                        
                    case MENU_PAGE_1:
                        if (menuCursor) {
                            if (ReadEEProm8(EEPROM_ADDR_DOOR_1)) {
                                WriteEEProm8(EEPROM_ADDR_DOOR_1, 0);
                            } else {
                                WriteEEProm8(EEPROM_ADDR_DOOR_1, 1);
                            }
                        } else {
                            if (ReadEEProm8(EEPROM_ADDR_ALLSENSORS)) {
                                WriteEEProm8(EEPROM_ADDR_ALLSENSORS, 0);
                            } else {
                                WriteEEProm8(EEPROM_ADDR_ALLSENSORS, 1);
                            }
                        }                        
                        break;
                        
                    case MENU_PAGE_2:
                        if (menuCursor) {
                            if (ReadEEProm8(EEPROM_ADDR_DOOR_2)) {
                                WriteEEProm8(EEPROM_ADDR_DOOR_2, 0);
                            } else {
                                WriteEEProm8(EEPROM_ADDR_DOOR_2, 1);
                            }
                        } else {
                            if (ReadEEProm8(EEPROM_ADDR_DOOR_1)) {
                                WriteEEProm8(EEPROM_ADDR_DOOR_1, 0);
                            } else {
                                WriteEEProm8(EEPROM_ADDR_DOOR_1, 1);
                            }
                        }                                                
                        break;
                        
                    case MENU_PAGE_3:
                        if (menuCursor) {
                            pageIndex = PER_CONTACT_PAGE;
                            colIndex = ReadPhoneNumber(EEPROM_ADDR_PERSONAL, &keypadBuffer);
                        } else {
                            if (ReadEEProm8(EEPROM_ADDR_DOOR_2)) {
                                WriteEEProm8(EEPROM_ADDR_DOOR_2, 0);
                            } else {
                                WriteEEProm8(EEPROM_ADDR_DOOR_2, 1);
                            }
                        }                                                
                        break;
                        
                    case PER_CONTACT_PAGE:
                        WritePhoneNumber(EEPROM_ADDR_PERSONAL, &keypadBuffer);
                        pageIndex = SEC_CONTACT_PAGE;
                        colIndex = ReadPhoneNumber(EEPROM_ADDR_SECURITY, &keypadBuffer);
                        break;
                        
                    case SEC_CONTACT_PAGE:
                        WritePhoneNumber(EEPROM_ADDR_SECURITY, &keypadBuffer);
                        pageIndex = PAL_CONTACT_PAGE;
                        colIndex = ReadPhoneNumber(EEPROM_ADDR_FRIEND, &keypadBuffer);
                        break;
                        
                    case PAL_CONTACT_PAGE:
                        WritePhoneNumber(EEPROM_ADDR_FRIEND, &keypadBuffer);
                        pageIndex = PER_CONTACT_PAGE;
                        colIndex = ReadPhoneNumber(EEPROM_ADDR_PERSONAL, &keypadBuffer);
                        break;

                    case OLD_PW_PAGE:
                        if (IsMatch()) {
                            pageIndex = NEW_PW_PAGE;
                            memset(keypadBuffer, 0, XLCD_COLS);
                            colIndex = 0;  
                            DisplayClearRow(2);
                        } else {
                            lastPageIndex = pageIndex;
                            pageIndex = INVALID_PW_PAGE;
                        }                        
                        break;
                        
                    case NEW_PW_PAGE:
                        pageIndex = REPEAT_PW_PAGE;
                        memcpy(tempBuffer, (const char*)keypadBuffer, XLCD_COLS);
                        memset(keypadBuffer, 0, XLCD_COLS);
                        colIndex = 0;                        
                        DisplayClearRow(2);
                        break;
                        
                    case REPEAT_PW_PAGE:
                        if (strncmp(keypadBuffer, tempBuffer, colIndex) == 0) {
                            for (idx=0; idx<XLCD_COLS; idx++) {
                                if (idx < colIndex) {
                                    WriteEEProm8(EEPROM_ADDR_CODE+idx, keypadBuffer[idx]);
                                } else {
                                    WriteEEProm8(EEPROM_ADDR_CODE+idx, 0);
                                }
                            }
                            pageIndex = CHANGE_SUCCESS_PAGE;
                        } else {
                            lastPageIndex = pageIndex;
                            pageIndex = CHANGE_FAILURE_PAGE;
                        }
                        break;                        
                }
                break;
                                
            case 'B':                                       // Escape
                switch (pageIndex) {
                    case MONITOR_PAGE:
                        pageIndex = START_PAGE;
                        break;
                        
                    case MENU_PAGE_0:
                    case MENU_PAGE_1:
                    case MENU_PAGE_2:
                    case MENU_PAGE_3:
                        pageIndex = MONITOR_PAGE;
                        break;
                        
                    case OLD_PW_PAGE:
                    case NEW_PW_PAGE:
                    case REPEAT_PW_PAGE:
                        if (colIndex) {
                            memset(keypadBuffer, 0, XLCD_COLS);
                            colIndex = 0;
                            DisplayClearRow(2);
                        } else {
                            pageIndex = MENU_PAGE_0;
                            menuCursor = 0;
                        }
                        break;
                        
                    case PER_CONTACT_PAGE:
                    case SEC_CONTACT_PAGE:
                    case PAL_CONTACT_PAGE:
                        if (colIndex) {
                            memset(keypadBuffer, 0, XLCD_COLS);
                            colIndex = 0;
                        } else {
                            pageIndex = MENU_PAGE_3;
                            menuCursor = 1;
                        }
                        break;
                }
                break;

            case 'C':                                       // Scroll Up
                switch (pageIndex) {
                    case MENU_PAGE_0:
                        if (menuCursor > 0) {
                            menuCursor--;
                        }
                        break;
                        
                    case MENU_PAGE_1:
                    case MENU_PAGE_2:
                    case MENU_PAGE_3:
                        if (menuCursor < 1) {
                            pageIndex--;
                        } else {
                            menuCursor--;
                        }
                        break;
                        
                    case PER_CONTACT_PAGE:
                        pageIndex = PAL_CONTACT_PAGE;
                        colIndex = ReadPhoneNumber(EEPROM_ADDR_FRIEND, &keypadBuffer);
                        break;
                        
                    case SEC_CONTACT_PAGE:
                        pageIndex = PER_CONTACT_PAGE;
                        colIndex = ReadPhoneNumber(EEPROM_ADDR_PERSONAL, &keypadBuffer);
                        break;
                        
                    case PAL_CONTACT_PAGE:
                        pageIndex = SEC_CONTACT_PAGE;
                        colIndex = ReadPhoneNumber(EEPROM_ADDR_SECURITY, &keypadBuffer);
                        break;
                }
                break;
                
            case 'D':                                       // Start
                break;
                                
            case 'E':                                       // Stop
                break;
                
            case 'F':                                       // Scroll Down
                switch (pageIndex) {
                    case MENU_PAGE_0:
                    case MENU_PAGE_1:
                    case MENU_PAGE_2:
                        if (menuCursor > 0) {
                            pageIndex++;
                        } else {
                            menuCursor++;
                        }
                        break;
                        
                    case MENU_PAGE_3:
                        if (menuCursor < 1) {
                            menuCursor++;
                        }
                        break;
                        
                    case PER_CONTACT_PAGE:
                        pageIndex = SEC_CONTACT_PAGE;
                        colIndex = ReadPhoneNumber(EEPROM_ADDR_SECURITY, &keypadBuffer);
                        break;
                        
                    case SEC_CONTACT_PAGE:
                        pageIndex = PAL_CONTACT_PAGE;
                        colIndex = ReadPhoneNumber(EEPROM_ADDR_FRIEND, &keypadBuffer);
                        break;
                        
                    case PAL_CONTACT_PAGE:
                        pageIndex = PER_CONTACT_PAGE;
                        colIndex = ReadPhoneNumber(EEPROM_ADDR_PERSONAL, &keypadBuffer);
                        break;                        
                }
                break;

            default:
                switch (pageIndex) {
                    case ENTER_PW_PAGE:
                    case OLD_PW_PAGE:
                    case NEW_PW_PAGE:
                    case REPEAT_PW_PAGE:
                        if (colIndex < XLCD_COLS) {
                            keypadBuffer[colIndex++] = kp;
                            DisplayRomOut(colIndex, 2, "*");
                        }
                        break;
                        
                    case PER_CONTACT_PAGE:
                    case SEC_CONTACT_PAGE:
                    case PAL_CONTACT_PAGE:
                        if (colIndex < XLCD_COLS) {
                            keypadBuffer[colIndex++] = kp;
                        }
                        break;
                }
                break;
        }
        
        DisplayShow();
        
        while (kp) {
            __delay_ms(10);
            kp = GetKeyPress();
        }
        __delay_ms(10);
    }
}

